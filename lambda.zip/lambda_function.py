import os
import psycopg2
import json

def get_db_connection():
    """Establish and return a database connection."""
    try:
        conn = psycopg2.connect(
            host=os.getenv("DB_HOST"),
            port=os.getenv("DB_PORT"),
            dbname=os.getenv("DB_NAME"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD")
        )
        return conn
    except Exception as e:
        raise Exception(f"Error connecting to the database: {str(e)}")

def lambda_handler(event, context):
    """Lambda function entry point."""
    # Parse input from the event
    name = event.get("name")
    email = event.get("email")

    if not name or not email:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Both 'name' and 'email' are required."})
        }

    # Connect to the database
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Insert data into the table
        insert_query = "INSERT INTO users (username, email) VALUES (%s, %s) RETURNING id;"
        cursor.execute(insert_query, (name, email))
        user_id = cursor.fetchone()[0]
        conn.commit()

        # Return success response
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "User created successfully", "user_id": user_id})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Error: {str(e)}"})
        }

    finally:
        # Ensure the connection is closed
        if conn:
            conn.close()

