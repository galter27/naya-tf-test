import psycopg2
import os

def lambda_handler(event, context):
    # Database connection parameters
    db_host = os.environ['DB_HOST']
    db_name = os.environ['DB_NAME']
    db_user = os.environ['DB_USER']
    db_password = os.environ['DB_PASSWORD']
    db_port = os.environ['DB_PORT']
    
    try:
        # Establish connection to the PostgreSQL database
        connection = psycopg2.connect(
            host=db_host,
            database=db_name,
            user=db_user,
            password=db_password,
            port=db_port
        )

        # Create a cursor object using a context manager
        with connection.cursor() as cursor:
            # Print the PostgreSQL database server version
            cursor.execute("SELECT version();")
            db_version = cursor.fetchone()
            print(f"Connected to database. Version: {db_version}")

        # Return success message
        return {
            'statusCode': 200,
            'body': f"Connected to database {db_name} at {db_host}. Database version: {db_version[0]}"
        }

    except Exception as error:
        print(f"Error while connecting to PostgreSQL: {error}")
        return {
            'statusCode': 500,
            'body': f"Error: {error}"
        }

    finally:
        if connection:
            connection.close()

