import psycopg2
import os
from psycopg2 import sql

# Fetch connection parameters from environment variables
host = os.getenv("DB_HOST")
port = os.getenv("DB_PORT", "5432")  # Default to 5432 if not set
dbname = os.getenv("DB_NAME")
username = os.getenv("DB_USER")
password = os.getenv("DB_PASSWORD")

def write_to_table(name, email):
    try:
        # Establish the connection to the database
        conn = psycopg2.connect(
            host=host,
            port=port,
            dbname=dbname,
            user=username,
            password=password
        )

        # Create a cursor object
        cur = conn.cursor()

        # Insert data into the table
        insert_query = sql.SQL("""
            INSERT INTO small_table (name, email)
            VALUES (%s, %s);
        """)

        # Execute the query with the provided values
        cur.execute(insert_query, (name, email))

        # Commit the transaction
        conn.commit()

        print(f"Data inserted: Name = {name}, Email = {email}")

    except Exception as e:
        print(f"Error: {e}")

    finally:
        # Close the cursor and the connection
        if conn:
            cur.close()
            conn.close()

# Example usage
write_to_table('Alice', 'alice@example.com')
write_to_table('Bob', 'bob@example.com')




